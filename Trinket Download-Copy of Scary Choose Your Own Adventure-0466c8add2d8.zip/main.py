import time

# Credit to ChatGPT for colored words code
class Colors:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
TV = r'''
                     _______________
                    |,----------.  |\
                    ||           |=| |
                    ||          || | |
                    ||       . _o| | | __
                    |`-----------' |/ /~/
                     ~~~~~~~~~~~~~~~ / /
                                    ~~
'''

print(TV)
print(Colors.GREEN + "Welcome to a scary text based adventure made by Phann Boon." + Colors.RESET)
time.sleep(5)
print(Colors.GREEN + "For best experience, play at night or in a dark room." + Colors.RESET)
time.sleep(5)
start = input(Colors.GREEN + "Are you ready? " + Colors.RESET)
if start == "yes":
  print(Colors.GREEN + "Good..." + Colors.RESET)
  time.sleep(5)
else:
  print(Colors.GREEN + "Too bad..." + Colors.RESET)
  time.sleep(5)
  
time.sleep(8)

print(Colors.BLUE + "Your father's working late again." + Colors.RESET)
time.sleep(5)
print(Colors.BLUE + "Your up watching TV again when you should be sleeping." + Colors.RESET)
time.sleep(5)
print(Colors.RED + "Ugh, I shouldn't have drunk all that soda, now I need to pee." + Colors.RESET)
time.sleep(5)
bathroom = input(Colors.GREEN + "Use the bathroom? " + Colors.RESET)
if bathroom == "no":
  print(Colors.RED + "I'll just wait until the movie is over and then go." + Colors.RESET)
  time.sleep(5)
  print(Colors.BLUE + "Around an hour later..." + Colors.RESET)
  time.sleep(5)
  print(Colors.RED + "Okay, now that the moive's over I really need to use the bathroom..." + Colors.RESET)
  time.sleep(5)
  print(Colors.RED + "...but it's kind of scary, I could just go to bed..." + Colors.RESET)
  time.sleep(5)
  bed = input(Colors.GREEN + "Bed or bathroom? " + Colors.RESET)
  if bed == "bed":
    print(Colors.BLUE + "You walk into your bedroom..." + Colors.RESET)
    time.sleep(5)
    print(Colors.BLUE + "You see your phone lying on the bed and you put it into your pocket" + Colors.RESET)
    time.sleep(5)
    print(Colors.BLUE + "You get in bed and try to go to sleep..." + Colors.RESET)
    time.sleep(8)
    print(Colors.BLUE + "Right before your about to drift off to sleep, you hear a rustling and faint breathing right outside your room..." + Colors.RESET)
    time.sleep(5)
    print(Colors.BLUE + "You think it might be your dad getting home" + Colors.RESET)
    time.sleep(5)
    dad = input(Colors.GREEN + "Call out to dad? " + Colors.RESET)
    if dad == "yes":
      print(Colors.RED + "Dad! Is that you?" + Colors.RESET)
      time.sleep(5)
      print(Colors.BLUE + "You wait but no one answers..." + Colors.RESET)
      time.sleep(5)
      callagain = input(Colors.GREEN + "Call again? " + Colors.RESET)
      if callagain == "yes":
        print(Colors.RED + "Dad? Hello? Are you there?" + Colors.RESET)
        time.sleep(5)
        print(Colors.BLUE + "The only answer from whatever is outside of your room is heavy breathing..." + Colors.RESET)
        time.sleep(5)
        print(Colors.BLUE + "You stop shouting because you suddenly realize that whatever is outside of your room is NOT your father..." + Colors.RESET)
        time.sleep(5)
        print(Colors.BLUE + "The door slowly creaks open and you see a shadowing figure in the door frame..." + Colors.RESET)
        time.sleep(5)
        print(Colors.BLUE + "You are frozen in your bed out of fear" + Colors.RESET)
        time.sleep(5)
        print(Colors.BLUE + "The figure in the doorway stares at you" + Colors.RESET)
        time.sleep(5)
        print(Colors.BLUE + "You feel like you must know what or who the figure is" + Colors.RESET)
        time.sleep(5)
        act = input(Colors.GREEN + "Attempt to turn on your bedside lamp or attempt to use your phone's flashlight? " + Colors.RESET)
        if act == "bedside lamp" or "attempt to turn on bedside lamp" or "attempt to turn on your bedside lamp":
          print(Colors.BLUE + "You attempt to quickly turn on the bedside lamp, but you realize with horror that the power is out..." + Colors.RESET)
          time.sleep(5)
          print(Colors.BLUE + "The figure, seeing your quick movement towards your beside light, lunges towards you, and knocks you unconcious..." + Colors.RESET)
          time.sleep(5)
          print(Colors.BLUE + "You wake up back on the couch, watching the same movie." + Colors.RESET)
          time.sleep(5)
          print(Colors.RED + "Huh, must have drifted off to sleep, I should go to bed." + Colors.RESET)
          time.sleep(5)
          print(Colors.BLUE + "When you're about to get up to go to bed, something bashes into your head and everything goes black..." + Colors.RESET)
          time.sleep(5)
          print(Colors.GREEN + "This is the end..." + Colors.RESET)
          time.sleep(5)
          quit()
        else:
          print(Colors.BLUE + "You silently dig around in your pants pocket for your phone..." + Colors.RESET)
          time.sleep(5)
          print(Colors.BLUE + "You pull your phone out of your pocket..." + Colors.RESET)
          time.sleep(5)
          print(Colors.BLUE + "You turn it on and shine the flashlight on the figure..." + Colors.RESET)
          time.sleep(5)
          print(Colors.BLUE + "Once the beam hits the figure, it shrieks and runs away before you can get a good look at it..." + Colors.RESET)
          time.sleep(5)
          print(Colors.RED + "That thing won't be gone for long..." + Colors.RESET)
          time.sleep(5)
          print(Colors.RED + "Luckily, I have a knife in my drawer." + Colors.RESET)
          time.sleep(5)
          chase = input(Colors.GREEN + "Grab your knife and chase after the creature?" + Colors.RESET)
          if chase == "yes":
            print(Colors.BLUE + "You grab your trusty knife and start running in the direction you thought the creature went." + Colors.RESET)
            time.sleep(8)
            print(Colors.RED + "This hallway is longer than I remember..." + Colors.RESET)
            time.sleep(8)
            print(Colors.BLUE + "You soon start to tire, the hallway doesn't seem to end..." + Colors.RESET)
            time.sleep(8)
            print(Colors.BLUE + "You stop to take a quick rest..." + Colors.RESET)
            time.sleep(8)
            print(Colors.BLUE + "While your resting, you feel something brush against your back..." + Colors.RESET)
            time.sleep(5)
            around = input(Colors.GREEN + "Turn around? " + Colors.RESET)
            if around == "yes":
              print(Colors.BLUE + "You slowly turn around..." + Colors.RESET)
              time.sleep(5)
              print(Colors.BLUE + "Whatever was behind you grabs you and drags you away, never to be seen again..." + Colors.RESET)
              time.sleep(5)
              print(Colors.GREEN + "This is the end..." + Colors.RESET)
              time.sleep(5)
              quit()
            else:
              print(Colors.BLUE + "You decide to not turn around and instead to slowly walk away..." + Colors.RESET)
              time.sleep(5)
              print(Colors.RED + "There's something stalking me..." + Colors.RESET)
              time.sleep(5)
              print(Colors.BLUE + "You hear the creature coming from a coridoor in front of you." + Colors.RESET)
              time.sleep(5)
              print(Colors.RED + "I might be able to hide from it, or I could ambush it behind the corner." + Colors.RESET)
              hide = input(Colors.GREEN + "Do you want to hide in the closet or hide behind the corner? " + Colors.RESET)
              if hide == "hide in the closet" or "closet" or "hide closet":
                print(Colors.BLUE + "You decide to hide in the closet and try to peek out to see what the creature is." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "As the creature creaps by, you try to peek through the crack and see what it is." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "You can't see very well, so you try to open the closet a little bit to see further..." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "The creature senes the slight movement and flings open the closet!" + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "The creature lunges towards you and you jolt awake in front of the TV. You must have fallen asleep..." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "You wake up back on the couch watching the same movie." + Colors.RESET)
                print(Colors.RED + "I'm too tired to finish this movie, I keep drifting off." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "You yawn and are about to get up to go to bed but then you see a slight movement behind the TV..." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "Something lunges towards you and it all goes black..." + Colors.RESET)
                time.sleep(5)
                print(Colors.GREEN + "This is the end..." + Colors.RESET)
                quit()
              else:
                print(Colors.RED + "I might be able to take the creature off guard if I hide behnd the corner..." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "You hide behind the corner, waiting for the creature..." + Colors.RESET)
                time.sleep(5)
                print(Colors.BLUE + "The creature comes around the corner and you plunge your knife deep into its heart...")
                time.sleep(5)
                print(Colors.BLUE + "")
else:
  bed = "bathroom"

if bed == "bathroom":
  print("(You get up and walk in the direction you think the bathroom is...)")
  time.sleep(5)
  print("(...you can't really see where your going in the dark...)")
  time.sleep(5)
  print("Finally, here's the bathroom!")
  time.sleep(5)
  print("That's weird...")
  time.sleep(5)
  print("...the door's locked.")
  time.sleep(5)
  print("Nobody else lives here besides me my dad and I thought he was at work.")
  time.sleep(5)
  print("Maybe he got home early without me noticing?")
  knock = input("Knock on the door? ")
  if knock == "yes":
    print("(You knock on the door)")
    time.sleep(5)
    print("(There's no answer...)")
    time.sleep(5)
    again = input("Knock again? ")
    if again == "yes":
      print("Maybe dad didn't hear me the first time so I'll knock again...")
      time.sleep(5)
      print("(You hear a thump from inside but no answer...)")
      time.sleep(5)
      print("Dad? Dad? Are you in there?")
      time.sleep(5)
      print("(There's still no answer...)")
      time.sleep(5)
      print("(You get a creepy feeling that something is wrong)")
      time.sleep(5)
      ask = input("Force the door or call 911? ")
      if ask == "force the door":
        door = "force the door"
      if ask == "call 911":
        print("(You reach into your pocket for your phone but it isn't there...")
        time.sleep(5)
        print("I must have left it on the couch from when I was watching the movie.")
        ask = input("Go back to couch to look for phone?")
        if ask == "no":
          door = input("Force the door or go to bed?")
      if door == "force the door":
          print("(You try to break down the door...)")
          time.sleep(5)
          print("(The door shatters)")
          time.sleep(5)
          print("(There's nobody's there, but the bathroom window is smashed and open...)")
          time.sleep(5)
          print("(It's started raining outside...)")
          time.sleep(5)
          window = input("Look out the window?")
          if window == "yes":
            print("(You look out the window but it's too dark to see anything)")
            time.sleep(5)
            if ask == "no":
              print("It's too bad I don't have my phone on me because then I could've used it's flashlight.")
            else:
              print("(You reach into your pocket for your phone but it isn't there...)")
              time.sleep(5)
              print("I must have left it on the couch from when I was watching the movie.")
              time.sleep(5)
            print("(You try to turn on the bathroom light...)")
            time.sleep(5)
            print("(You realize with dread that the power is out)")
            time.sleep(5)
            print("(You don't know if this was done by a person or the storm...)")
            time.sleep(5)
            light = input("Check on the breaker box in the basement?")
              
  
  
  
  
  
  
  